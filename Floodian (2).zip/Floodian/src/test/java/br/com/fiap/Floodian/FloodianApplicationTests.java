package br.com.fiap.Floodian;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FloodianApplicationTests {

	@Test
	void contextLoads() {
	}

}
