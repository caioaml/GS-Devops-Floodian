package br.com.fiap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FloodianApplication {

	public static void main(String[] args) {
		SpringApplication.run(FloodianApplication.class, args);
	}

}
